2018-08-22T18:25:00+00:00
Scanning /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/custom
Including file extensions: php,inc,module,lib
Processed 32768 lines contained in 316 files.
Processing took 19.373155832291 seconds.

# nuance
#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/custom/prof2prof/modules/prof2prof_pages/prof2prof_pages.module
* funcGetArg
 * Line 578: `  $args = func_get_args();`
 * Line 675: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/custom/prof2prof/prof2prof.module
* foreachByReference
 * Line 514: `    foreach ($results as &$result) {`

