2018-08-22T18:17:48+00:00
Scanning /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib
Including file extensions: php,inc,module,lib
Processed 409971 lines contained in 1773 files.
Processing took 115.50745797157 seconds.

# nuance
#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/addressfield/addressfield.module
* foreachByReference
 * Line 385: `  foreach ($items as $delta => &$item) {`
 * Line 400: `    foreach ($item as $key => &$value) {`
 * Line 761: `  foreach ($properties as $key => &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/addressfield/views/addressfield.views.inc
* foreachByReference
 * Line 41: `  foreach ($data as &$table) {`
 * Line 56: `      foreach ($table as $column_name => &$column) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/better_exposed_filters/better_exposed_filters_exposed_form_plugin.inc
* funcGetArg
 * Line 1667: `      return (func_get_arg(0));`
 * Line 1670: `    $params = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/commentaccess/commentaccess.module
* foreachByReference
 * Line 223: `    foreach ($conditions as $key => &$condition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/conditional_fields/conditional_fields.module
* foreachByReference
 * Line 948: `    foreach ($values as $delta => &$value) {`
 * Line 951: `        foreach ($value as $key => &$element_value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/ctools.module
* funcGetArg
 * Line 731: `  foreach (func_get_args() as $arg) {`
 * Line 756: `  foreach (func_get_args() as $arg) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/drush/ctools.drush.inc
* funcGetArg
 * Line 331: `  $table_names = func_get_args();`
 * Line 438: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/includes/context.inc
* funcGetArg
 * Line 107: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/includes/export-ui.inc
* funcGetArg
 * Line 406: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/page_manager/page_manager.admin.inc
* funcGetArg
 * Line 379: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/page_manager/plugins/tasks/page.admin.inc
* foreachByReference
 * Line 1256: `    foreach ($handlers as &$handler) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/page_manager/plugins/tasks/page.inc
* funcGetArg
 * Line 249: `  foreach (func_get_args() as $count => $arg) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/page_manager/plugins/tasks/search.inc
* funcGetArg
 * Line 91: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ctools/plugins/export_ui/ctools_export_ui.class.php
* funcGetArg
 * Line 582: `      'function args' => func_get_args(),`
 * Line 613: `      'function args' => func_get_args(),`
 * Line 659: `      'function args' => func_get_args(),`
 * Line 1102: `      'function args' => func_get_args(),`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/date/date_views/includes/date_views.views.inc
* foreachByReference
 * Line 123: `  foreach ($data as $base_table => &$table) {`
 * Line 124: `    foreach ($table as $id => &$field) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/devel/devel.drush.inc
* funcGetArg
 * Line 67: `  $projects = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/devel/devel.module
* funcGetArg
 * Line 468: `    $args = func_get_args();`
 * Line 483: `    $args = func_get_args();`
 * Line 1815: `  $args = func_get_args();`
* foreachByReference
 * Line 1050: `        foreach ($queries as &$query) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/devel/devel_node_access.module
* funcGetArg
 * Line 223: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/devel/krumo/class.krumo.php
* funcGetArg
 * Line 486: `      $_ = func_get_args();`
 * Line 1112: `  $_ = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/diff/diff.pages.inc
* foreachByReference
 * Line 503: `    foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/draggableviews/draggableviews_book/draggableviews_book.module
* foreachByReference
 * Line 51: `  foreach ($keyed_result as &$item) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/ds/ds.module
* foreachByReference
 * Line 683: `    foreach ($layout_render_array as $region => &$fields) {`
 * Line 684: `      foreach ($fields as $field_key => &$field) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/entityform/entityform.api.php
* foreachByReference
 * Line 127: `  foreach ($autofields as &$autofield) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/entityform/entityform.module
* funcGetArg
 * Line 669: `  $args = func_get_args();`
 * Line 932: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/entityreference/entityreference.module
* foreachByReference
 * Line 585: `          foreach ($behavior_elements as $key => &$behavior_element) {`
* funcGetArg
 * Line 935: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/entityreference/plugins/behavior/EntityReferenceBehavior_ViewsFilterSelect.class.php
* foreachByReference
 * Line 6: `    foreach ($data as $table_name => &$table_data) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/entityreference/plugins/selection/EntityReference_SelectionHandler_Generic.class.php
* foreachByReference
 * Line 408: `    foreach ($conditions as $key => &$condition) {`
 * Line 468: `    foreach ($conditions as $key => &$condition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/features/features.drush.inc
* funcGetArg
 * Line 241: `  $args = func_get_args();`
 * Line 451: `  if ($args = func_get_args()) {`
 * Line 507: `  if ($args = func_get_args()) {`
 * Line 535: `  $features_to_exclude = func_get_args();`
 * Line 685: `  if ($args = func_get_args()) {`
 * Line 782: `  $features_to_exclude = func_get_args();`
 * Line 818: `  if (!$args = func_get_args()) {`
 * Line 903: `  $features_to_exclude = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/features/features.export.inc
* foreachByReference
 * Line 1052: `  foreach ($item as $key => &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/features/features.module
* funcGetArg
 * Line 535: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/features/tests/features_test/features_test.features.inc
* funcGetArg
 * Line 10: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/feeds.drush.inc
* foreachByReference
 * Line 226: `    foreach ($rows as &$row) {`
* funcGetArg
 * Line 552: `  $missing = array_diff(func_get_args(), $all);`
 * Line 553: `  $to_enable = array_diff(func_get_args(), $enabled, $missing);`
 * Line 554: `  $already_enabled = array_intersect(func_get_args(), $enabled);`
 * Line 564: `  elseif (count(func_get_args()) == 0) {`
 * Line 587: `  $to_disable = array_intersect(func_get_args(), $enabled);`
 * Line 588: `  $missing = array_diff(func_get_args(), $all);`
 * Line 589: `  $already_disabled = array_diff(func_get_args(), $enabled, $missing);`
 * Line 599: `  elseif (count(func_get_args()) == 0) {`
 * Line 621: `  $to_delete = array_intersect_key($all, array_flip(func_get_args()));`
 * Line 622: `  $missing = array_diff(func_get_args(), array_keys($all));`
 * Line 640: `  elseif (count(func_get_args()) == 0) {`
 * Line 660: `  $missing = array_diff(func_get_args(), array_keys($all));`
 * Line 661: `  $to_revert = array_intersect_key($all, array_flip(func_get_args()));`
 * Line 688: `  elseif (count(func_get_args()) == 0) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/feeds.module
* funcGetArg
 * Line 1206: `  $additional_args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/includes/FeedsImporter.inc
* foreachByReference
 * Line 216: `    foreach ($period as &$p) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/libraries/common_syndication_parser.inc
* funcGetArg
 * Line 326: `  $rdf_properties = is_array($rdf_properties) ? $rdf_properties : array_slice(func_get_args(), 1);`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/libraries/http_request.inc
* foreachByReference
 * Line 415: `    foreach ($reverse_cparts as $i => &$part) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/plugins/FeedsNodeProcessor.inc
* foreachByReference
 * Line 367: `      foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/plugins/FeedsProcessor.inc
* foreachByReference
 * Line 830: `      foreach ($mappings as &$mapping) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/feeds/tests/feeds_tests.module
* foreachByReference
 * Line 95: `  foreach ($images as &$image) {`
 * Line 112: `  foreach ($images as &$image) {`
 * Line 130: `  foreach ($images as &$image) {`
 * Line 150: `  foreach ($images as &$image) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/field_collection/field_collection.module
* foreachByReference
 * Line 456: `  foreach ($items as &$item) {`
 * Line 509: `  foreach ($items as $delta => &$item) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/field_group/field_group.module
* funcGetArg
 * Line 102: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/flag/tests/flag_hook_test/flag_hook_test.module
* funcGetArg
 * Line 43: `  _flag_hook_test_record_invocation('hook_flag_flag', func_get_args(), $flagging);`
 * Line 49: `  _flag_hook_test_record_invocation('hook_flag_unflag', func_get_args(), $flagging);`
 * Line 56: `    _flag_hook_test_record_invocation('hook_entity_presave', func_get_args(), $entity);`
 * Line 64: `    _flag_hook_test_record_invocation('hook_entity_insert', func_get_args(), $entity);`
 * Line 72: `    _flag_hook_test_record_invocation('hook_entity_update', func_get_args(), $entity);`
 * Line 80: `    _flag_hook_test_record_invocation('hook_entity_delete', func_get_args(), $entity);`
 * Line 134: `  _flag_hook_test_record_invocation('rules_event', func_get_args());`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/fontawesome/drush/fontawesome.drush.inc
* funcGetArg
 * Line 64: `  $args = func_get_args();`
 * Line 97: `  $extensions = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/libraries/libraries.drush.inc
* funcGetArg
 * Line 102: `  foreach (pm_parse_arguments(func_get_args(), FALSE) as $machine_name) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/libraries/libraries.module
* foreachByReference
 * Line 236: `  foreach ($file_types as &$files) {`
 * Line 357: `    foreach ($libraries as $machine_name => &$properties) {`
 * Line 375: `    foreach ($libraries as &$properties) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/link/link.module
* foreachByReference
 * Line 591: `    foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/menu_attributes/menu_attributes.module
* foreachByReference
 * Line 106: `  foreach ($attributes as $attribute => &$info) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag.i18n.inc
* foreachByReference
 * Line 124: `    foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag.inc
* foreachByReference
 * Line 275: `      foreach ($values as $key => &$image_value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag.module
* foreachByReference
 * Line 302: `    foreach ($configs as $instance => &$config) {`
 * Line 1960: `    foreach ($elements as $name => &$element) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_context/metatag_context.i18n.inc
* foreachByReference
 * Line 109: `    foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_context/metatag_context.module
* funcGetArg
 * Line 106: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_context/tests/metatag_context_tests.module
* funcGetArg
 * Line 10: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_dc/metatag_dc.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_dc_advanced/metatag_dc_advanced.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_google_plus/metatag_google_plus.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_hreflang/metatag_hreflang.metatag.inc
* foreachByReference
 * Line 17: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_hreflang/metatag_hreflang.module
* foreachByReference
 * Line 67: `      foreach ($output as $tag_name => &$tag) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_opengraph/metatag_opengraph.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/metatag/metatag_twitter_cards/metatag_twitter_cards.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/og/includes/views/handlers/og_handler_field_group_permissions.inc
* foreachByReference
 * Line 22: `      foreach ($list as &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/og/og_context/og_context.module
* foreachByReference
 * Line 281: `  foreach ($group_context_providers as &$group_context_provider) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/og/og_register/og_register.module
* foreachByReference
 * Line 103: `  foreach ($values as &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/og/og_ui/og_ui.admin.inc
* foreachByReference
 * Line 102: `  foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/panels/includes/common.inc
* foreachByReference
 * Line 335: `    foreach ($allowed_content_types as &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/panels/includes/legacy.inc
* funcGetArg
 * Line 20: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/panels/panels.module
* funcGetArg
 * Line 1427: `  $args = func_get_args();`
* foreachByReference
 * Line 1749: `  foreach ($handlers as &$handler) {`
 * Line 1763: `  foreach ($pages as &$page) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/panels/panels_mini/panels_mini.module
* foreachByReference
 * Line 382: `  foreach ($mini_panels as &$mini_panel) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/panels/plugins/display_renderers/panels_renderer_editor.class.php
* funcGetArg
 * Line 433: `    $args = func_get_args();`
 * Line 1225: `    $args = func_get_args();`
 * Line 1248: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/privatemsg/privatemsg.module
* funcGetArg
 * Line 1857: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/recaptcha/recaptcha-php/tests/ReCaptcha/RequestMethod/PostTest.php
* funcGetArg
 * Line 96: `        return call_user_func(PostTest::$assert, func_get_args());`
 * Line 99: `    return call_user_func_array('file_get_contents', func_get_args());`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/rules/includes/rules.core.inc
* foreachByReference
 * Line 216: `    foreach ($query_conditions as &$condition) {`
* funcGetArg
 * Line 521: `    return $this->executeByArgs(func_get_args());`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/rules/rules.drush.inc
* funcGetArg
 * Line 83: `  $args = func_get_args();`
 * Line 105: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/rules/rules.module
* funcGetArg
 * Line 927: `  $args = func_get_args();`
 * Line 962: `  $args = func_get_args();`
 * Line 1014: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/simplecrop/includes/simplecrop.pages.inc
* funcGetArg
 * Line 10: `  $form_parents = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/token/token.pages.inc
* funcGetArg
 * Line 259: `  $args = func_get_args();`
 * Line 294: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/viewerjs/drush/viewerjs.drush.inc
* funcGetArg
 * Line 52: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/drush/views.drush.inc
* funcGetArg
 * Line 114: `  $viewnames = _convert_csv_to_array(func_get_args());`
 * Line 406: `  $viewnames = _convert_csv_to_array(func_get_args());`
 * Line 417: `  $viewnames = _convert_csv_to_array(func_get_args());`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/handlers/views_handler_field.inc
* foreachByReference
 * Line 256: `    foreach ($classes as &$class) {`
 * Line 301: `    foreach ($classes as &$class) {`
 * Line 312: `    foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/handlers/views_handler_relationship_groupwise_max.inc
* foreachByReference
 * Line 274: `    foreach ($conditions as $condition_id => &$condition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/includes/admin.inc
* funcGetArg
 * Line 98: `    $args = array_slice(func_get_args(), 2);`
 * Line 2609: `  $args = func_get_args();`
* foreachByReference
 * Line 3565: `    foreach ($new_fields as &$new_field) {`
 * Line 4807: `  foreach ($rows as &$row) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/modules/comment.views.inc
* foreachByReference
 * Line 651: `    foreach ($build as $cid => &$comment_build) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/modules/field/views_handler_field_field.inc
* foreachByReference
 * Line 611: `      foreach ($values as $row_id => &$value) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/modules/search/views_handler_argument_search.inc
* foreachByReference
 * Line 64: `        foreach ($condition_conditions  as $key => &$condition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/modules/search/views_handler_filter_search.inc
* foreachByReference
 * Line 147: `        foreach ($condition_conditions  as $key => &$condition) {`
 * Line 197: `      foreach ($conditions as $key => &$subcondition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/modules/system/views_handler_argument_file_fid.inc
* foreachByReference
 * Line 21: `    foreach ($titles as &$title) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/plugins/export_ui/views_ui.class.php
* funcGetArg
 * Line 280: `      'function args' => func_get_args(),`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/plugins/views_plugin_display.inc
* foreachByReference
 * Line 198: `      foreach ($filters as &$filter) {`
* funcGetArg
 * Line 927: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/plugins/views_plugin_style.inc
* foreachByReference
 * Line 122: `      foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/plugins/views_wizard/views_ui_base_views_wizard.class.php
* foreachByReference
 * Line 502: `            foreach ($path_fields as &$field) {`
 * Line 516: `    foreach ($display_options as &$options) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/views.api.php
* foreachByReference
 * Line 1101: `  foreach ($commands as &$command) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/views.module
* funcGetArg
 * Line 505: `  $args = func_get_args();`
 * Line 929: `  $args = func_get_args();`
 * Line 2044: `  $args = func_get_args();`
 * Line 2073: `  $args = func_get_args();`
* foreachByReference
 * Line 2001: `  foreach ($conditions as $condition_id => &$condition) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views/views_ui.module
* funcGetArg
 * Line 739: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views_bulk_operations/views_bulk_operations.drush.inc
* funcGetArg
 * Line 82: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views_data_export/views_data_export.drush.inc
* funcGetArg
 * Line 317: `  $arrays = func_get_args();`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/views_slideshow/contrib/views_slideshow_cycle/views_slideshow_cycle.drush.inc
* funcGetArg
 * Line 89: `    func_get_args()`
 * Line 101: `    func_get_args()`
 * Line 113: `    func_get_args()`
 * Line 125: `    func_get_args()`
 * Line 137: `    func_get_args()`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/wysiwyg/editors/tinymce.inc
* foreachByReference
 * Line 1318: `  foreach ($plugins as &$plugin) {`


# critical
#### /Users/raymond/PrometSource/prof2prof/www/sites/all/modules/contrib/field_group/field_group.module
* variableInterpolation
 * Line 1975: `    $code .= "  \${$export['identifier']}s['" . check_plain($object->$export['key']) . "'] = \${$export['identifier']};\n\n";`

