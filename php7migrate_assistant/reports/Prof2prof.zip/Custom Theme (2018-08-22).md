2018-08-22T18:25:40+00:00
Scanning /Users/raymond/PrometSource/prof2prof/www/sites/all/themes
Including file extensions: php,inc,module,lib
Processed 11805 lines contained in 127 files.
Processing took 8.3725690841675 seconds.

# nuance
#### /Users/raymond/PrometSource/prof2prof/www/sites/all/themes/bootstrap/includes/alter.inc
* foreachByReference
 * Line 389: `    foreach ($build as &$icon) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/themes/bootstrap/includes/cdn.inc
* foreachByReference
 * Line 73: `      foreach ($providers as $name => &$data) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/themes/bootstrap/includes/common.inc
* funcGetArg
 * Line 521: `  $hash = drupal_hash_base64(serialize(func_get_args()));`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/themes/bootstrap/templates/file/file-widget-multiple.func.php
* foreachByReference
 * Line 44: `  foreach ($widgets as $key => &$widget) {`

#### /Users/raymond/PrometSource/prof2prof/www/sites/all/themes/custom/bootstrap_prof2prof/template.php
* foreachByReference
 * Line 512: `    foreach ($rows as &$row) {`

