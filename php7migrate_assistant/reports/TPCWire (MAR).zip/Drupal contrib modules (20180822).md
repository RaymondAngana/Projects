2018-08-22T01:52:54+00:00
Scanning /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib
Including file extensions: php,inc,module,lib
Processed 899559 lines contained in 2966 files.
Processing took 165.5993950367 seconds.

# nuance
#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/DateTime.php
* funcGetArg
 * Line 630: `		$dateArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 687: `		$dateArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Engineering.php
* funcGetArg
 * Line 1652: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1682: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Financial.php
* funcGetArg
 * Line 832: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 939: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Logical.php
* funcGetArg
 * Line 98: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 150: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/LookupRef.php
* funcGetArg
 * Line 235: `		$args = func_get_args();`
 * Line 329: `		$args = func_get_args();`
 * Line 397: `		$chooseArgs = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/MathTrig.php
* funcGetArg
 * Line 256: `		foreach(PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $value) {`
 * Line 329: `		foreach(PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $value) {`
 * Line 539: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 619: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 653: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 768: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 836: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 895: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 946: `		$arrayList = func_get_args();`
 * Line 981: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Statistical.php
* funcGetArg
 * Line 630: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 675: `		foreach (PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args()) as $k => $arg) {`
 * Line 715: `		foreach (PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args()) as $k => $arg) {`
 * Line 1052: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1083: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1110: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1288: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1532: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1586: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1681: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1722: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1905: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1937: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2011: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2050: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2082: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2185: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2332: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2477: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2554: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2615: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2673: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2715: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2762: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2804: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 3009: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3051: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3088: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 3136: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3173: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/TextData.php
* funcGetArg
 * Line 147: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation.php
* funcGetArg
 * Line 2457: `		return func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/ReferenceHelper.php
* foreachByReference
 * Line 229: `		foreach ($aComments as $key => &$value) {`
 * Line 255: `		foreach ($aMergeCells as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/Matrix.php
* funcGetArg
 * Line 58: `			$args = func_get_args();`
 * Line 152: `			$args = func_get_args();`
 * Line 383: `			$args = func_get_args();`
 * Line 416: `			$args = func_get_args();`
 * Line 463: `			$args = func_get_args();`
 * Line 496: `			$args = func_get_args();`
 * Line 544: `			$args = func_get_args();`
 * Line 578: `			$args = func_get_args();`
 * Line 626: `			$args = func_get_args();`
 * Line 679: `			$args = func_get_args();`
 * Line 713: `			$args = func_get_args();`
 * Line 747: `			$args = func_get_args();`
 * Line 780: `			$args  = func_get_args();`
 * Line 868: `			$args = func_get_args();`
 * Line 915: `			$args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/utils/Maths.php
* funcGetArg
 * Line 32: `	foreach (func_get_args() as $d) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PCLZip/pclzip.lib.php
* funcGetArg
 * Line 267: `      $v_arg_list = func_get_args();`
 * Line 433: `      $v_arg_list = func_get_args();`
 * Line 664: `      $v_arg_list = func_get_args();`
 * Line 802: `      $v_arg_list = func_get_args();`
 * Line 925: `      $v_arg_list = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/qrcode.php
* foreachByReference
 * Line 609: `			foreach ($frame as &$frameLine) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Worksheet.php
* foreachByReference
 * Line 2210: `		foreach ($rangeBlocks as &$rangeSet) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/better_exposed_filters/better_exposed_filters_exposed_form_plugin.inc
* funcGetArg
 * Line 1667: `      return (func_get_arg(0));`
 * Line 1670: `    $params = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/ckeditor/includes/ckeditor.drush.inc
* funcGetArg
 * Line 42: `  $args = func_get_args();`
 * Line 61: `  $modules = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder.drush.inc
* funcGetArg
 * Line 46: `  $files = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_review/coder_review.drush.inc
* funcGetArg
 * Line 307: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_review/coder_review.module
* foreachByReference
 * Line 107: `      foreach ($package as $module_name => &$module) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/coder_upgrade.api.php
* foreachByReference
 * Line 265: `  foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/conversions/begin.inc
* foreachByReference
 * Line 134: `            foreach ($module_theme as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/conversions/install.inc
* foreachByReference
 * Line 43: `  foreach ($comments as &$comment) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/includes/conversion.inc
* foreachByReference
 * Line 352: `  foreach ($upgrades as $name => &$upgrade) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/includes/main.inc
* foreachByReference
 * Line 375: `  foreach ($nodes as &$node) {`
 * Line 418: `  foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/tests/new/samples/example.module
* foreachByReference
 * Line 3097: `  foreach ($nodes as $nid => &$node) {`
 * Line 3099: `    foreach ($node_additions as $property => &$value) {`
 * Line 3110: `  foreach ($nodes as $nid => &$node) {`
 * Line 3112: `    foreach ($additions as $property => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/colorbox/drush/colorbox.drush.inc
* funcGetArg
 * Line 71: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/date/date_views/includes/date_views.views.inc
* foreachByReference
 * Line 123: `  foreach ($data as $base_table => &$table) {`
 * Line 124: `    foreach ($table as $id => &$field) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/devel/devel.drush.inc
* funcGetArg
 * Line 67: `  $projects = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/devel/devel.module
* funcGetArg
 * Line 467: `    $args = func_get_args();`
 * Line 482: `    $args = func_get_args();`
 * Line 1844: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/devel/devel_node_access.module
* funcGetArg
 * Line 223: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/devel/krumo/class.krumo.php
* funcGetArg
 * Line 486: `      $_ = func_get_args();`
 * Line 1116: `  $_ = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/diff/diff.pages.inc
* foreachByReference
 * Line 503: `    foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/features/features.drush.inc
* funcGetArg
 * Line 241: `  $args = func_get_args();`
 * Line 451: `  if ($args = func_get_args()) {`
 * Line 507: `  if ($args = func_get_args()) {`
 * Line 535: `  $features_to_exclude = func_get_args();`
 * Line 685: `  if ($args = func_get_args()) {`
 * Line 782: `  $features_to_exclude = func_get_args();`
 * Line 818: `  if (!$args = func_get_args()) {`
 * Line 903: `  $features_to_exclude = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/features/features.export.inc
* foreachByReference
 * Line 1052: `  foreach ($item as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/features/features.module
* funcGetArg
 * Line 535: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/features/tests/features_test/features_test.features.inc
* funcGetArg
 * Line 10: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/feeds.module
* funcGetArg
 * Line 1138: `  $additional_args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/includes/FeedsImporter.inc
* foreachByReference
 * Line 216: `    foreach ($period as &$p) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/libraries/common_syndication_parser.inc
* funcGetArg
 * Line 284: `  $rdf_properties = is_array($rdf_properties) ? $rdf_properties : array_slice(func_get_args(), 1);`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/libraries/http_request.inc
* foreachByReference
 * Line 415: `    foreach ($reverse_cparts as $i => &$part) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/plugins/FeedsNodeProcessor.inc
* foreachByReference
 * Line 367: `      foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/plugins/FeedsProcessor.inc
* foreachByReference
 * Line 829: `      foreach ($mappings as &$mapping) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds/tests/feeds_tests.module
* foreachByReference
 * Line 71: `  foreach ($images as &$image) {`
 * Line 88: `  foreach ($images as &$image) {`
 * Line 106: `  foreach ($images as &$image) {`
 * Line 126: `  foreach ($images as &$image) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds_tamper/feeds_tamper.inc
* foreachByReference
 * Line 156: `  foreach ($instances as &$instance_list) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds_tamper/feeds_tamper_ui/feeds_tamper_ui.admin.inc
* foreachByReference
 * Line 273: `  foreach ($plugins as &$p) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/field_collection/field_collection.module
* foreachByReference
 * Line 369: `  foreach ($items as &$item) {`
 * Line 408: `  foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/fuzzysearch/includes/processor_excerpt.inc
* foreachByReference
 * Line 59: `      foreach ($keys as $key => &$v) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/fuzzysearch/includes/processor_search.inc
* foreachByReference
 * Line 66: `    foreach ($items as &$item) {`
 * Line 67: `      foreach ($item as $name => &$field) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/fuzzysearch/includes/service.inc
* foreachByReference
 * Line 716: `    foreach ($keys as $i => &$nested) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/imagecache_actions/image_styles_admin/image_styles_admin.module
* foreachByReference
 * Line 113: `    foreach ($first_row as $i => &$cell) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/libraries/libraries.drush.inc
* funcGetArg
 * Line 102: `  foreach (pm_parse_arguments(func_get_args(), FALSE) as $machine_name) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/libraries/libraries.module
* foreachByReference
 * Line 236: `  foreach ($file_types as &$files) {`
 * Line 357: `    foreach ($libraries as $machine_name => &$properties) {`
 * Line 375: `    foreach ($libraries as &$properties) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/link/link.module
* foreachByReference
 * Line 591: `    foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/geofield/geofield.module
* foreachByReference
 * Line 462: `  foreach ($properties as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/geophp/geoPHP/geoPHP.inc
* funcGetArg
 * Line 39: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/geophp/geoPHP/lib/geometry/Geometry.class.php
* funcGetArg
 * Line 75: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/leaflet/leaflet.module
* foreachByReference
 * Line 76: `    foreach ($features as &$feature) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/leaflet/leaflet_views/leaflet_views_plugin_style.inc
* foreachByReference
 * Line 289: `            foreach ($points as &$point) {`
 * Line 295: `            foreach ($points as &$point) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/leaflet_more_maps/leaflet_more_maps.admin.inc
* foreachByReference
 * Line 80: `  foreach ($custom_maps as &$custom_map) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/openlayers/drush/openlayers.drush.inc
* funcGetArg
 * Line 60: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/openlayers/modules/openlayers_views/views/openlayers_views_style_data.inc
* foreachByReference
 * Line 405: `    foreach ($features as &$feature) {`
 * Line 416: `    foreach ($features as $k => &$feature) {`
 * Line 462: `    foreach ($features as $k => &$f) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/proj4js/drush/proj4js.drush.inc
* funcGetArg
 * Line 60: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/menu_attributes/menu_attributes.module
* foreachByReference
 * Line 106: `  foreach ($attributes as $attribute => &$info) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/menu_block/menu_block.follow.inc
* foreachByReference
 * Line 20: `    foreach ($tree as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/menu_block/menu_block.module
* foreachByReference
 * Line 567: `    foreach ($tree_with_trail as $key => &$value) {`
 * Line 589: `  foreach ($tree as $key => &$value) {`
 * Line 629: `      foreach ($tree as $key => &$value) {`
 * Line 650: `    foreach ($tree as $key => &$value) {`
 * Line 694: `  foreach ($tree as $key => &$value) {`
 * Line 738: `  foreach ($tree as $key => &$value) {`
 * Line 745: `  foreach ($items as $i => &$data) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/menu_block/menu_block.sort.inc
* foreachByReference
 * Line 20: `    foreach ($current_level as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag.i18n.inc
* foreachByReference
 * Line 124: `    foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag.inc
* foreachByReference
 * Line 275: `      foreach ($values as $key => &$image_value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag.module
* foreachByReference
 * Line 302: `    foreach ($configs as $instance => &$config) {`
 * Line 1960: `    foreach ($elements as $name => &$element) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_context/metatag_context.i18n.inc
* foreachByReference
 * Line 113: `    foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_context/metatag_context.module
* funcGetArg
 * Line 106: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_context/tests/metatag_context_tests.module
* funcGetArg
 * Line 10: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_dc/metatag_dc.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_dc_advanced/metatag_dc_advanced.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_google_plus/metatag_google_plus.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_hreflang/metatag_hreflang.metatag.inc
* foreachByReference
 * Line 17: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_hreflang/metatag_hreflang.module
* foreachByReference
 * Line 67: `      foreach ($output as $tag_name => &$tag) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_opengraph/metatag_opengraph.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/metatag/metatag_twitter_cards/metatag_twitter_cards.metatag.inc
* foreachByReference
 * Line 10: `  foreach ($configs as &$config) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/formats/dsv.inc
* foreachByReference
 * Line 105: `  foreach ($var as $k => &$v) {`
 * Line 195: `    foreach ($array as &$row) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/modules/node_export_book/node_export_book.module
* foreachByReference
 * Line 53: `    foreach ($nodes as &$node) {`
 * Line 67: `    foreach ($child_nodes as &$node) {`
 * Line 82: `    foreach ($child_nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/modules/node_export_dependency/node_export_dependency.core.inc
* foreachByReference
 * Line 125: `        foreach ($field_dependencies as &$field_dependency) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/modules/node_export_dependency/node_export_dependency.module
* foreachByReference
 * Line 93: `  foreach ($dependencies as $dep_key => &$dependency) {`
 * Line 188: `      foreach ($dependencies as $dep_key => &$dependency) {`
 * Line 468: `      foreach ($dependencies as &$dependency) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/modules/node_export_relation/node_export_relation.node_reference.inc
* foreachByReference
 * Line 43: `          foreach ($items as $key => &$node_reference) {`
 * Line 67: `        foreach ($items as &$node_reference) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/modules/node_export_relation/node_export_relation.og.inc
* foreachByReference
 * Line 32: `  foreach ($nodes as &$node) {`
 * Line 63: `  foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/node_export.drush.inc
* funcGetArg
 * Line 136: `  $args = array_filter(func_get_args(), 'is_numeric');`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/node_export/node_export.module
* foreachByReference
 * Line 154: `  foreach ($nodes as &$node) {`
 * Line 169: `  foreach ($nodes as &$node) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/nodequeue/includes/nodequeue.admin.inc
* funcGetArg
 * Line 992: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/nodequeue/nodequeue_generate.drush.inc
* funcGetArg
 * Line 53: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/nodequeue/smartqueue.module
* foreachByReference
 * Line 120: `    foreach ($field_names as $field_name => &$tids) {`
 * Line 126: `    foreach ($field_names as $field_name => &$tids) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels/includes/common.inc
* foreachByReference
 * Line 335: `    foreach ($allowed_content_types as &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels/includes/legacy.inc
* funcGetArg
 * Line 20: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels/panels.module
* funcGetArg
 * Line 1427: `  $args = func_get_args();`
* foreachByReference
 * Line 1749: `  foreach ($handlers as &$handler) {`
 * Line 1763: `  foreach ($pages as &$page) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels/panels_mini/panels_mini.module
* foreachByReference
 * Line 382: `  foreach ($mini_panels as &$mini_panel) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels/plugins/display_renderers/panels_renderer_editor.class.php
* funcGetArg
 * Line 433: `    $args = func_get_args();`
 * Line 1225: `    $args = func_get_args();`
 * Line 1248: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/panels_extras/menu_seo_title/menu_seo_title.module
* foreachByReference
 * Line 182: `  foreach ($tree as &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/redirect/redirect.admin.inc
* funcGetArg
 * Line 29: `  $keys = func_get_args();`
 * Line 640: `  $keys = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/redirect/redirect.drush.inc
* funcGetArg
 * Line 42: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/rules/includes/rules.core.inc
* foreachByReference
 * Line 216: `    foreach ($query_conditions as &$condition) {`
* funcGetArg
 * Line 521: `    return $this->executeByArgs(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/rules/rules.drush.inc
* funcGetArg
 * Line 83: `  $args = func_get_args();`
 * Line 105: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/rules/rules.module
* funcGetArg
 * Line 928: `  $args = func_get_args();`
 * Line 963: `  $args = func_get_args();`
 * Line 1015: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/callback_add_url.inc
* foreachByReference
 * Line 11: `    foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/callback_add_viewed_entity.inc
* foreachByReference
 * Line 65: `    foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/callback_language_control.inc
* foreachByReference
 * Line 92: `    foreach ($items as $i => &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/callback_node_status.inc
* foreachByReference
 * Line 34: `    foreach ($items as $nid => &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/index_entity.inc
* foreachByReference
 * Line 486: `    foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/includes/processor.inc
* foreachByReference
 * Line 186: `    foreach ($items as &$item) {`
 * Line 187: `      foreach ($item as $name => &$field) {`
 * Line 223: `      foreach ($value as &$v) {`
 * Line 232: `        foreach ($value as $i => &$v) {`
 * Line 246: `      foreach ($value as &$token) {`
 * Line 321: `      foreach ($keys as $key => &$v) {`
 * Line 339: `    foreach ($filters as $key => &$f) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/search_api.module
* foreachByReference
 * Line 1765: `    foreach ($types as &$type_info) {`
 * Line 2193: `    foreach ($fields as &$info) {`
 * Line 2218: `  foreach ($fields as $field => &$info) {`
 * Line 2270: `      foreach ($nested_fields as &$info) {`
 * Line 2283: `    foreach ($value as &$v) {`
 * Line 2804: `  foreach ($field_value as &$nested_value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/search_api/tests/search_api_test.module
* foreachByReference
 * Line 190: `    foreach ($res as &$x) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/DateTime.php
* funcGetArg
 * Line 630: `		$dateArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 687: `		$dateArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Engineering.php
* funcGetArg
 * Line 1652: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1682: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Financial.php
* funcGetArg
 * Line 832: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 939: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Logical.php
* funcGetArg
 * Line 98: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 150: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/LookupRef.php
* funcGetArg
 * Line 235: `		$args = func_get_args();`
 * Line 329: `		$args = func_get_args();`
 * Line 397: `		$chooseArgs = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/MathTrig.php
* funcGetArg
 * Line 256: `		foreach(PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $value) {`
 * Line 329: `		foreach(PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $value) {`
 * Line 539: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 619: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 653: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 768: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 836: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 895: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`
 * Line 946: `		$arrayList = func_get_args();`
 * Line 981: `		foreach (PHPExcel_Calculation_Functions::flattenArray(func_get_args()) as $arg) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Statistical.php
* funcGetArg
 * Line 630: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 675: `		foreach (PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args()) as $k => $arg) {`
 * Line 715: `		foreach (PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args()) as $k => $arg) {`
 * Line 1052: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1083: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1110: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1288: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1532: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1586: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1681: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 1722: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1905: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 1937: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2011: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2050: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2082: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2185: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2332: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2477: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2554: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2615: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 2673: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2715: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2762: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 2804: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 3009: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3051: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3088: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`
 * Line 3136: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`
 * Line 3173: `		$aArgs = PHPExcel_Calculation_Functions::flattenArrayIndexed(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/TextData.php
* funcGetArg
 * Line 147: `		$aArgs = PHPExcel_Calculation_Functions::flattenArray(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation.php
* funcGetArg
 * Line 2457: `		return func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/ReferenceHelper.php
* foreachByReference
 * Line 229: `		foreach ($aComments as $key => &$value) {`
 * Line 255: `		foreach ($aMergeCells as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/Matrix.php
* funcGetArg
 * Line 58: `			$args = func_get_args();`
 * Line 152: `			$args = func_get_args();`
 * Line 383: `			$args = func_get_args();`
 * Line 416: `			$args = func_get_args();`
 * Line 463: `			$args = func_get_args();`
 * Line 496: `			$args = func_get_args();`
 * Line 544: `			$args = func_get_args();`
 * Line 578: `			$args = func_get_args();`
 * Line 626: `			$args = func_get_args();`
 * Line 679: `			$args = func_get_args();`
 * Line 713: `			$args = func_get_args();`
 * Line 747: `			$args = func_get_args();`
 * Line 780: `			$args  = func_get_args();`
 * Line 868: `			$args = func_get_args();`
 * Line 915: `			$args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/utils/Maths.php
* funcGetArg
 * Line 32: `	foreach (func_get_args() as $d) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PCLZip/pclzip.lib.php
* funcGetArg
 * Line 267: `      $v_arg_list = func_get_args();`
 * Line 433: `      $v_arg_list = func_get_args();`
 * Line 664: `      $v_arg_list = func_get_args();`
 * Line 802: `      $v_arg_list = func_get_args();`
 * Line 925: `      $v_arg_list = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/qrcode.php
* foreachByReference
 * Line 609: `			foreach ($frame as &$frameLine) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Worksheet.php
* foreachByReference
 * Line 2210: `		foreach ($rangeBlocks as &$rangeSet) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/taxonomy_csv/import/taxonomy_csv.import.line.api.inc
* foreachByReference
 * Line 839: `          foreach ($array as &$new_value) {`
 * Line 848: `          foreach ($array as &$new_value) {`
 * Line 889: `          foreach ($array as &$new_value) {`
 * Line 898: `          foreach ($array as &$new_value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/taxonomy_manager/taxonomy_manager.admin.inc
* funcGetArg
 * Line 2351: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/token/token.pages.inc
* funcGetArg
 * Line 259: `  $args = func_get_args();`
 * Line 294: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid/uuid.core.inc
* foreachByReference
 * Line 210: `    foreach ($entities as &$entity) {`
 * Line 389: `  foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid/uuid.entity.inc
* foreachByReference
 * Line 514: `  foreach ($things as &$object) {`
 * Line 569: `  foreach ($things as &$object) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid/uuid.features.inc
* foreachByReference
 * Line 113: `            foreach ($items as &$item) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid/uuid_path/uuid_path.module
* foreachByReference
 * Line 32: `    foreach ($aliases as &$alias) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid/uuid_services_example/uuid_services_example.features.inc
* funcGetArg
 * Line 10: `  list($module, $api) = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/uuid_features/includes/uuid_features.drush.inc
* funcGetArg
 * Line 40: `  if ($args = func_get_args()) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/video_embed_field/video_embed_field.field.inc
* foreachByReference
 * Line 64: `  foreach ($properties as $key => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/video_embed_field/views/video_embed_field.views.inc
* foreachByReference
 * Line 20: `  foreach ($data as &$table) {`
 * Line 35: `      foreach ($table as $column_name => &$column) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/drush/views.drush.inc
* funcGetArg
 * Line 114: `  $viewnames = _convert_csv_to_array(func_get_args());`
 * Line 406: `  $viewnames = _convert_csv_to_array(func_get_args());`
 * Line 417: `  $viewnames = _convert_csv_to_array(func_get_args());`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/handlers/views_handler_field.inc
* foreachByReference
 * Line 256: `    foreach ($classes as &$class) {`
 * Line 301: `    foreach ($classes as &$class) {`
 * Line 312: `    foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/handlers/views_handler_relationship_groupwise_max.inc
* foreachByReference
 * Line 274: `    foreach ($conditions as $condition_id => &$condition) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/includes/admin.inc
* funcGetArg
 * Line 98: `    $args = array_slice(func_get_args(), 2);`
 * Line 2609: `  $args = func_get_args();`
* foreachByReference
 * Line 3565: `    foreach ($new_fields as &$new_field) {`
 * Line 4807: `  foreach ($rows as &$row) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/modules/comment.views.inc
* foreachByReference
 * Line 651: `    foreach ($build as $cid => &$comment_build) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/modules/field/views_handler_field_field.inc
* foreachByReference
 * Line 611: `      foreach ($values as $row_id => &$value) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/modules/search/views_handler_argument_search.inc
* foreachByReference
 * Line 64: `        foreach ($condition_conditions  as $key => &$condition) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/modules/search/views_handler_filter_search.inc
* foreachByReference
 * Line 147: `        foreach ($condition_conditions  as $key => &$condition) {`
 * Line 197: `      foreach ($conditions as $key => &$subcondition) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/modules/system/views_handler_argument_file_fid.inc
* foreachByReference
 * Line 21: `    foreach ($titles as &$title) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/plugins/export_ui/views_ui.class.php
* funcGetArg
 * Line 280: `      'function args' => func_get_args(),`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/plugins/views_plugin_display.inc
* foreachByReference
 * Line 198: `      foreach ($filters as &$filter) {`
* funcGetArg
 * Line 927: `    $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/plugins/views_plugin_style.inc
* foreachByReference
 * Line 122: `      foreach ($classes as &$class) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/plugins/views_wizard/views_ui_base_views_wizard.class.php
* foreachByReference
 * Line 502: `            foreach ($path_fields as &$field) {`
 * Line 516: `    foreach ($display_options as &$options) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/views.api.php
* foreachByReference
 * Line 1101: `  foreach ($commands as &$command) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/views.module
* funcGetArg
 * Line 505: `  $args = func_get_args();`
 * Line 929: `  $args = func_get_args();`
 * Line 2044: `  $args = func_get_args();`
 * Line 2073: `  $args = func_get_args();`
* foreachByReference
 * Line 2001: `  foreach ($conditions as $condition_id => &$condition) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views/views_ui.module
* funcGetArg
 * Line 739: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views_bulk_operations/views_bulk_operations.drush.inc
* funcGetArg
 * Line 82: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/views_data_export/views_data_export.drush.inc
* funcGetArg
 * Line 317: `  $arrays = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/webform/webform.module
* funcGetArg
 * Line 3226: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/xmlsitemap/xmlsitemap.module
* foreachByReference
 * Line 847: `      foreach ($link_info as $key => &$info) {`
* funcGetArg
 * Line 1321: `  $args = func_get_args();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/xmlsitemap/xmlsitemap_modal/xmlsitemap_modal.module
* funcGetArg
 * Line 18: `  $args = func_get_args();`


# syntax
#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Functions.php
* syntax
 * Line 570: `	}	//	function acosh() //Fatal error: 'break' not in the 'loop' or 'switch' context on line 570`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/tests/new/samples/example.module
* syntax
 * Line 2648: `      'name' => st('Page'), //Parse error: syntax error, unexpected 'else' (T_ELSE) on line 2648`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/coder_upgrade/tests/old/samples/example.module
* syntax
 * Line 305: `    // //Fatal error: Cannot redeclare example_perm() (previously declared:289) on line 305`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds_tamper/plugins/default_value.inc
* syntax
 * Line 36: `  } //Fatal error: Redefinition of parameter $source on line 36`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mapping/openlayers_kml_layer/openlayers_kml_layer.module
* syntax
 * Line 114: `  return array( //Parse error: syntax error, unexpected '&' on line 114`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Calculation/Functions.php
* syntax
 * Line 570: `	}	//	function acosh() //Fatal error: 'break' not in the 'loop' or 'switch' context on line 570`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/taxonomy_csv/import/taxonomy_csv.import.line.api.inc
* syntax
 * Line 377: `  return $result; //Fatal error: 'break' not in the 'loop' or 'switch' context on line 377`


# critical
#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/examples/benchmark.php
* oldClassConstructors
 * Line 116: `	}	//	function Benchmark()`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/tests/TestMatrix.php
* oldClassConstructors
 * Line 4: `  function TestMatrix() {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PCLZip/pclzip.lib.php
* deprecatedFunctions
 * Line 4580: `	$this->magic_quotes_status = @get_magic_quotes_runtime();`
 * Line 4583: `	  @set_magic_quotes_runtime(0);`
 * Line 4609: `  	  @set_magic_quotes_runtime($this->magic_quotes_status);`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/fonts/utils/makefont.php
* deprecatedFunctions
 * Line 60: `	set_magic_quotes_runtime(0);`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/SN-Tracker-7.x-master/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/tcpdf.php
* deprecatedFunctions
 * Line 6997: `			@set_magic_quotes_runtime($mqr);`
 * Line 7011: `			return @get_magic_quotes_runtime();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/coder/scripts/coder_format/tests/CoderTestFile.php
* oldClassConstructors
 * Line 155: `  function Text_Diff_Renderer_parallel($title) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/feeds_tamper/plugins/default_value.inc
* duplicateFunctionParameter
 * Line 29: `function feeds_tamper_default_value_callback($source, $item_key, $element_key, &$field, $settings, $source) {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/mimemail/modules/mimemail_compress/mimemail_compress.inc
* oldClassConstructors
 * Line 31: `  public function mimemail_compress($html = '', $css = '') {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/examples/benchmark.php
* oldClassConstructors
 * Line 116: `	}	//	function Benchmark()`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/JAMA/tests/TestMatrix.php
* oldClassConstructors
 * Line 4: `  function TestMatrix() {`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PCLZip/pclzip.lib.php
* deprecatedFunctions
 * Line 4580: `	$this->magic_quotes_status = @get_magic_quotes_runtime();`
 * Line 4583: `	  @set_magic_quotes_runtime(0);`
 * Line 4609: `  	  @set_magic_quotes_runtime($this->magic_quotes_status);`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/fonts/utils/makefont.php
* deprecatedFunctions
 * Line 60: `	set_magic_quotes_runtime(0);`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/sntracker/sn_tracker_report/PHPExcel/Classes/PHPExcel/Shared/PDF/tcpdf.php
* deprecatedFunctions
 * Line 6997: `			@set_magic_quotes_runtime($mqr);`
 * Line 7011: `			return @get_magic_quotes_runtime();`

#### /Users/raymond/PrometSource/tpcwire/docroot/sites/all/modules/contrib/webform/includes/webform.export.inc
* oldClassConstructors
 * Line 86: `  function webform_exporter_delimited($options) {`
 * Line 135: `  function webform_exporter_excel($options) {`

