2018-08-22T02:09:32+00:00
Scanning /Users/raymond/PrometSource/tpcwire/docroot/themes
Including file extensions: php,inc,module,lib
Processed 1546 lines contained in 17 files.
Processing took 0.91213297843933 seconds.
